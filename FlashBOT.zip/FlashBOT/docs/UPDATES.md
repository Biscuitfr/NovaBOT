## 🔄 • List of Updates:
> ** **
> - **Update [1.0.0]:**
>
> → Official Release of T.F.A's Tools V2.0.
> 
> → Fixed Select Menu collection values Error.
> 
>** **
>
> - **Update [1.0.1]:**
>
> → Added new commands: `timeout.js`, `ship.js`, `skin.js` and `achievement.js`.
>
> → AutoMod Update: Changed Auto Mute from Giving the role Muted to Timeout Function.
> 
> ** **
> 
> - **Update [1.0.2]:**
>
> → Add new command: `remove-timeout.js`.
> 
> ** **
>
> - **Update [1.0.3]:**
>
> → Add new commands: `meme.js` and `troll.js`.
>
> ** **
>
> - **Update [1.0.4]:**
>
> → Add new commands: `secret_number.js` and `calculate.js`.
>
> → New Folder `examples_cmds` with some of Commands Examples.
>
> ** **
>
> - **Update [1.0.5]:**
>
> → Updated command `nick.js`: Changed new nick generator from numbers only to numbers and strings.  | Add message embeds and removed normal messages.
>
> ** **
>
> - **Update [1.0.6]:**
>
> → YT API Handler Fixed: Youtube API Key is now not important, But some commands can't execute.
>
> → Command Bugged: The command `user_info.js` is having an issue when you use the command and mention a user, this bug will be fixed soon.
>
> ** **
>
> - **Update [1.0.6.1]:**
>
> → Fixed Handlers in `index.js`: Added YT-API Handler and Updated the text for Client Handler console messages.
>
> → New "T.F.A" Ascii in Console if you starts the Project.
>
> ** **
> - **Update [1.0.6.2] ALPHA:**
> 
> → Commands Fixed: `warnings.js` and `user_info.js`.
>
> → New Command: `user_id.js`.
>
> → Updated File: `README.md`.